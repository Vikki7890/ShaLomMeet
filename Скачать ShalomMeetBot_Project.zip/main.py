# Основной бот
print('Bot starting...')